library(testthat)
library(EpiModelHIV)

test_check("EpiModelHIV")
