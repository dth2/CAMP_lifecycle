
#ifndef CHANGESTATS_H
#define CHANGESTATS_H

#include "edgetree.h"
#include "changestat.h"

CHANGESTAT_FN(d_absdiffnodemix);
CHANGESTAT_FN(d_absdiffby);

#endif
